function ApproachSection() {
    return (
      <section className="approach">
        <h2>Our Approach</h2>
        <p>We help you find and connect with mentors to achieve your goals.</p>
      </section>
    );
  }
  
  export default ApproachSection;
  